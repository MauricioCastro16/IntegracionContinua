import{e}from"./BNRMaQ6w.js";e();
